

fetch("https://images-api.nasa.gov/")
    .then(respuesta => respuesta.json())
    .then(datos =>{
        console.log(datos)
    });