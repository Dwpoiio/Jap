let btnAgregar = document.getElementById("agregar");
let inputItem = document.getElementById("item");
let elContainer = document.getElementById("contenedor");
let btnLimpiar = document.getElementById("limpiar");

let array = [];
let arrayRefresh = [];

arrayRefresh = JSON.parse(localStorage.getItem('listado'));

if (arrayRefresh == null) {
    arrayRefresh = [];
}

for (item of arrayRefresh) {
    elContainer.innerHTML += `<li>${item}</li>`
}

function valor() {
    if (inputItem.value) {
        array = arrayRefresh;
        array.push(inputItem.value);
        localStorage.setItem('listado', JSON.stringify(array));
        elContainer.innerHTML = '';
        for (item of array) {
            elContainer.innerHTML += `<li>${item}</li>`
        }
        inputItem.value = '';
    } else {
        console.log("no funciona");
    }
}

btnAgregar.addEventListener("click", valor);

btnLimpiar.addEventListener("click", event => {
    localStorage.clear();
    elContainer.innerHTML = '';
    array = [];
    arrayRefresh = [];
});