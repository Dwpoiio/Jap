let inputBuscar = document.getElementById("buscar")
let arrayBusqueda = ["hola", "valor", "pepe", "bulbasur", "hol1", "hola2", "Hola", "@", "HOLA"]

function funBuscar(evento) {
    let resultados = arrayBusqueda.filter(item => {
        let itemUpperCase = item.toUpperCase()
        return itemUpperCase.includes(inputBuscar.value.toUpperCase());
    })
    elContainer.innerHTML = resultados
}

buscar.addEventListener("input", funBuscar)