let contrasena = document.getElementById("contrasena");
let repetirContrasena = document.getElementById("repetirContrasena");
let btnRegistrarme = document.getElementById("btnRegistrarme");

// Example starter JavaScript for disabling form submissions if there are invalid fields
(function () {
    'use strict'
    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.querySelectorAll('.needs-validation')
    // Loop over them and prevent submission
    Array.prototype.slice.call(forms)
        // console.log(contrasena.value)
        .forEach(function (form) {
            form.addEventListener('submit', function (event) {
                if (!form.checkValidity() || (contrasena.value !== repetirContrasena.value)) {
                    event.preventDefault()
                    event.stopPropagation()
                }
                form.classList.add('was-validated')
            }, false)
        })
})()

repetirContrasena.addEventListener("input", event => {
    if (contrasena.value != repetirContrasena.value) {
        event.preventDefault()
        formulario.classList.remove('was-validated')
        repetirContrasena.classList.remove("was-validated")
        repetirContrasena.classList.remove("is-valid")
        repetirContrasena.classList.add("is-invalid")
    } else if ((contrasena.value == repetirContrasena.value)) {
        repetirContrasena.classList.remove("is-invalid")
        repetirContrasena.classList.add("is-valid")
    }
})


