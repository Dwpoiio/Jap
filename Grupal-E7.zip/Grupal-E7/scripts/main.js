const URL = "https://636e26a0b567eed48ad49ff7.mockapi.io/"
let btnSearch = document.getElementById("btnGet1"),
btnPost = document.getElementById("btnPost"),
btnPut = document.getElementById("btnPut"),
btnDelete = document.getElementById("btnDelete");

async function fetchear(url) {
    let respuesta = await fetch(url);
    let datos = await respuesta.json();
    // console.log(respuesta);
    console.log(datos);
};


btnSearch.addEventListener('click', event =>{ // 7.1 Funcion buscar por id

});


btnPost.addEventListener('click', event =>{ // 7.2 Funcion agregar

});


btnPut.addEventListener('click', event =>{ // 7.3 Funcion modificar

});

btnDelete.addEventListener('click', event =>{ // 7.4 Funcion borrar
});

fetchear(URL + 'users');