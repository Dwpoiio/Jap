let FLIX_URL = "https://japceibal.github.io/japflix_api/movies-data.json"
let movieList= document.getElementById("lista")
let searchValue = document.getElementById("inputBuscar")
let searchButton = document.getElementById("btnBuscar")
let movieArray = []
let movieArrayOriginal = []
let movieTitle = document.getElementById("scroll-title")
let movieP = document.getElementById("scroll-p")

let getJSONData = function(url){
    let result = {};
    return fetch(url)
    .then(response => {
      if (response.ok) {
        return response.json();
      }else{
        throw Error(response.statusText);
      }
    })
    .then(function(response) {
          result.status = 'ok';
          result.data = response;
          return result;
    })
    .catch(function(error) {
        result.status = 'error';
        result.data = error;
        return result;
    });
}

function showMovies(){
    let show = ""
    for(let i = 0; i < movieArray.length; i++){
        let movie = movieArray[i]        
        let stars= ""
        for(let i = 1; i <= Math.round(movie.vote_average/2); i++){
            stars +=`<span class="fa fa-star checked"></span>`
        }        
        for(let i = 1; i <= 5 - Math.round(movie.vote_average/2); i++){
           stars +=`<span class="fa fa-star"></span>`
        }

        show +=
        `
        <li class="movie-container" id="container-movie" data-bs-toggle="offcanvas" data-bs-target="#offcanvasScrolling">
            <p class="movie-title-p"><b>${movie.title}</b></p><p class="movie-score-p">${stars}</p>
            <p class="movie-overview-p">${movie.tagline}</p>
        </li>    
        `
        

        movieTitle.innerHTML = movie.title
        for(let genre of movie.genres){
            movieP.innerHTML += genre.name
        } 
        
    } movieList.innerHTML += show

    // let dropdownDiv = document.createElement("div")
    //     for(let genre of movieArray){
    //         console.log(genre)
    //         for(let manzana of genre.genres){
    //             let p = document.createTextNode(manzana.name)
    //         movieP.appendChild(p) 
    //         }      
    //     }

        

}

searchButton.addEventListener("click", function(e){
    if(searchValue.value === ""){
        e.preventDefault();
    }else{        
        e.preventDefault();
    getJSONData(FLIX_URL).then(function(resultObj){
        if(resultObj.status==="ok"){        
            movieArray = resultObj.data
            movieArrayOriginal = resultObj.data
            let filtValue = searchValue.value
            let filteredMovies =  movieArrayOriginal.filter( movie => {
            return movie.title.includes(filtValue) || movie.overview.includes(filtValue) || movie.tagline.includes(filtValue) || movie.genres[0].name.includes(filtValue)            
    })
        movieArray = filteredMovies
        showMovies()
        }
    });
}});



    