let usuarios = [
    {
        nombre: "Ana",
        apellido: "Peréz",
        edad: 32,
        quiereConquistarElMundo: false
    },
    {
        nombre: "Napoleón",
        apellido: "III",
        edad: 65,
        quiereConquistarElMundo: true
    },
    {
        nombre: "El Rufi",
        edad: 3,
        quiereConquistarElMundo: true
    },
];


function escribirP(texto) {
    let myElement = document.createElement('p');
    let myText = document.createTextNode(texto);
    myElement.appendChild(myText);
    document.body.appendChild(myElement);
};

for (let usuario of usuarios) {
    escribirP("Nombre: " + usuario.nombre);
    if (usuario.apellido) {
        escribirP("Apellido: " + usuario.apellido);
    }
    escribirP("Edad: " + usuario.edad);
    escribirP("Conquistar el mundo:" + usuario.quiereConquistarElMundo);
    let br = document.createElement('br');
    document.body.appendChild(br);
};








