const LIBROS_URL = "https://gutendex.com/books/"
// Tomo los tres botones
let ordenar = document.getElementById("alfabeticamente");
let ascendente = document.getElementById("nacimiento_ascendente");
let descendente = document.getElementById("nacimiento_descendente");
let inputMin = document.getElementById("min");
let inputMax = document.getElementById("max");
let buttonFilter = document.getElementById("filter");

fetch(LIBROS_URL)
    .then(response => response.json())
    .then(({ results }) => {
        let Libros = document.querySelector("#libros");

        function elFor() {
            for (i = 0; i < results.length; i++) {
                Libros.innerHTML += `<li><b>Titulo:</b> ${results[i].title}<br><b>Autor:</b> ${results[i].authors[0].name}<br><b>Nacimiento:</b> ${results[i].authors[0].birth_year}<br><b>Fallecimiento:</b> ${results[i].authors[0].death_year}<hr></li>`;
            }
        }
        elFor();

        ascendente.addEventListener("click", event => {
            results.sort(function (a, b) {
                if (a.authors[0].birth_year < b.authors[0].birth_year) {
                    return -1;
                }
                if (a.authors[0].birth_year > b.authors[0].birth_year) {
                    return 1;
                }
                return 0;
            })

            Libros.innerHTML = "";
            elFor();
        });

        descendente.addEventListener("click", event => {
            results.sort(function (b, a) {
                if (a.authors[0].birth_year < b.authors[0].birth_year) {
                    return -1;
                }
                if (a.authors[0].birth_year > b.authors[0].birth_year) {
                    return 1;
                }
                return 0;
            })
            Libros.innerHTML = "";
            elFor();
        });

        ordenar.addEventListener("click", event => {
            results.sort(function (a, b) {
                if (a.authors[0].name < b.authors[0].name) {
                    return -1;
                }
                if (a.authors[0].name > b.authors[0].name) {
                    return 1;
                }
                return 0;
            })
            Libros.innerHTML = "";
            elFor();
        });

        // buttonFilter.addEventListener("click", event => {
        //     results.filter(function (libro) {
        //         if(inputMin.value >)
        //     })
        // })
    });
