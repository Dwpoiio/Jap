function saludar(){
    alert("Bienvenid@!!")
}

saludar();