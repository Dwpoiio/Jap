let variableLocal = localStorage.getItem("nombreDelPoke")
let divMuestra = document.getElementById("pokemon-html")
fetch("https://pokeapi.co/api/v2/pokemon/" + variableLocal)
    .then(res => res.json())
    .then(datos => {
        console.log(datos)
        divMuestra.innerHTML += `<img src="${datos.sprites.front_default}" alt=""><br>`
        for (habilidades of datos.abilities){
            divMuestra.innerHTML += `${habilidades.ability.name}<br>`
        }
        for (forStats of datos.stats){
            divMuestra.innerHTML += `${forStats.stat.name} ${forStats.base_stat} <br>`
        }
        
        
    })