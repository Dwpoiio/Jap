let variableLocal = localStorage.getItem("nombreDelPoke")
let divMuestra = document.getElementById("pokemon-html")
fetch("https://pokeapi.co/api/v2/pokemon/" + variableLocal)
    .then(res => res.json())
    .then(datos => {
        console.log(datos)
        for (habilidades of datos.abilities){
            divMuestra.innerHTML += `${habilidades.ability.name}<br><br>`
        }
        for (forStats of datos.stats){
            divMuestra.innerHTML += `${forStats.stat.name}<br><br>`
        }
        
        // ${datos.sprites}`
    })

