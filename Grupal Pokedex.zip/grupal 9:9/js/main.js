let laLista = document.getElementById("listaPoke")
var datosimg = []
fetch("https://pokeapi.co/api/v2/pokemon")
    .then(res => res.json())
    .then(datos => {
        datosimg = datos.results;
        for (let listaPoke of datos.results) {
            let btnPoke = document.createElement("button");
            laLista.appendChild(btnPoke);
            btnPoke.innerHTML = `${listaPoke.name}`;
            fetch("https://pokeapi.co/api/v2/pokemon/" + listaPoke.name)
                .then(res => res.json())
                .then(info => {
                    console.log(info)
                    btnPoke.innerHTML += `<img src="${info.sprites.front_default}" alt=""><br>`
                })

            btnPoke.addEventListener("click", function () {
                localStorage.setItem("nombreDelPoke", listaPoke.name)
                location.href = ("pokemon.html");
            })
        }
    });