let inputBuscar = document.getElementById("inputBuscar");
let btnBuscar = document.getElementById("btnBuscar")
let contenedor = document.getElementById("contenedor")

function funBuscar() {
    localStorage.setItem("buscar", inputBuscar.value)
    window.location.href = ("index.html")
}

btnBuscar.addEventListener("click", funBuscar)
let busqueda = localStorage.getItem("buscar", inputBuscar.value)

fetch("https://images-api.nasa.gov/search?q=" + busqueda)
    .then(respuesta => respuesta.json())
    .then(datos => {

        if (datos.collection.items.length < 1) {
            alert("No se encontraron resultados")
        } else {

            for (let item of datos.collection.items) {

                let divHijo = document.createElement("div");

                let pDescripcion = document.createElement("div");
                let pTitulo = document.createElement("div");
                let pFecha = document.createElement("div");
                let imgDiv = document.createElement("div");
                let pImg = document.createElement("img");

                pTitulo.innerHTML = `${item.data[0].title}`;
                pFecha.innerHTML = `${item.data[0].date_created}`;
                pDescripcion.innerHTML = `${item.data[0].description}`;
                pImg.setAttribute("src", `${item.links[0].href}`);
                pImg.setAttribute("alt", "fotoNasa");
                imgDiv.setAttribute("id", "divImg")
                pDescripcion.setAttribute("class", "descripcion")

                contenedor.appendChild(divHijo);

                divHijo.appendChild(imgDiv);
                imgDiv.appendChild(pImg);
                divHijo.appendChild(pTitulo);
                divHijo.appendChild(pFecha);
                divHijo.appendChild(pDescripcion);
            }
        }
    });