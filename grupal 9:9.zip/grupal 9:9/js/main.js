let laLista = document.getElementById("listaPoke")

fetch("https://pokeapi.co/api/v2/pokemon")
    .then(res => res.json())
    .then(datos => {
        console.log(datos)


        for (let listaPoke of datos.results) {
            let btnPoke = document.createElement("button");
            laLista.appendChild(btnPoke);
            btnPoke.innerHTML = `${listaPoke.name}`;
            btnPoke.addEventListener("click", function () {
                localStorage.setItem("nombreDelPoke", listaPoke.name)
                location.href = ("pokemon.html");
                console.log(listaPoke)
            })
        }


    });