let contra = document.getElementById('contra1');
let repContra = document.getElementById('contra2');
let but = document.getElementById('boton');
let terminos = document.getElementById('terminos');
let invalidCheck = document.getElementById('invalidCheck');

repContra.addEventListener("input", event => {
  if (contra.value == repContra.value && contra.checkValidity()) {
    repContra.setCustomValidity("")
  } else {
    repContra.setCustomValidity(false)
  }
});

but.addEventListener("click", event => {
  if (!invalidCheck.checkValidity()) {
    terminos.classList.add('is-invalid')
  } else {
    terminos.classList.remove('is-invalid')
  }

});

invalidCheck.addEventListener("click", event => {
  if (invalidCheck.checkValidity()) {
    terminos.classList.remove('is-invalid')
  } else {
    terminos.classList.add('is-invalid')
  }

});

// Example starter JavaScript for disabling form submissions if there are invalid fields
(function () {
  'use strict'

  // Fetch all the forms we want to apply custom Bootstrap validation styles to
  var forms = document.querySelectorAll('.needs-validation')

  // Loop over them and prevent submission
  Array.prototype.slice.call(forms)
    .forEach(function (form) {
      form.addEventListener('submit', function (event) {
        if (!form.checkValidity()) {
          event.preventDefault()
          event.stopPropagation()
        }

        form.classList.add('was-validated')
      }, false)
    })
})()


