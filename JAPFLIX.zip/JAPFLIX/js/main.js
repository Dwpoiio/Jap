let movieList = document.getElementById("lista")
let searchValue = document.getElementById("inputBuscar")
let searchButton = document.getElementById("btnBuscar")
let movieArray = []
let movieArrayOriginal = []
let movieTitle = document.getElementById("scroll-title")
let movieP = document.getElementById("scroll-p")

fetch("https://japceibal.github.io/japflix_api/movies-data.json")
    .then(result => result.json())
    .then(data => {

        function showMovies() {
            movieList.innerHTML = ""
            for (let i = 0; i < movieArray.length; i++) {
                let movie = movieArray[i]
                let stars = ""
                for (let i = 1; i <= Math.round(movie.vote_average / 2); i++) {
                    stars += `<span class="fa fa-star checked"></span>`
                }
                for (let i = 1; i <= 5 - Math.round(movie.vote_average / 2); i++) {
                    stars += `<span class="fa fa-star"></span>`
                }

                let peliFiltrada = document.createElement("div");
                peliFiltrada.innerHTML = ""
                peliFiltrada.innerHTML = `<ul class="list-group container">
        <li class="movie-container" id="container-movie" data-bs-toggle="offcanvas" data-bs-target="#offcanvasScrolling">
            <p class="movie-title-p"><b>${movie.title}</b></p><p class="movie-score-p">${stars}</p>
            <p class="movie-overview-p">${movie.tagline}</p>
        </li>   
        </ul> 
        `
                peliFiltrada.addEventListener("click", funMostrar => {

                    movieP.innerHTML = ""
                    document.getElementById("anio").innerHTML = ""
                    document.getElementById("duracion").innerHTML = ""
                    document.getElementById("presupuesto").innerHTML = ""
                    document.getElementById("ganancia").innerHTML = ""

                    movieTitle.innerHTML = movie.title;
                    let pOver = document.createTextNode(movie.overview)
                    movieP.appendChild(pOver)
                    for (let recorrer of movie.genres) {
                        let p = document.createTextNode(recorrer.name + " ")
                        movieP.appendChild(p)
                    }
                    let anioLanz = document.createTextNode("Year: " + movie.release_date.slice(0, 4))
                    let duracion = document.createTextNode("Runtime: " + movie.runtime + " min")
                    let presupuesto = document.createTextNode("Budget: $" + movie.budget)
                    let ganancia = document.createTextNode("Revenue: $" + movie.revenue)

                    document.getElementById("anio").appendChild(anioLanz)
                    document.getElementById("duracion").appendChild(duracion)
                    document.getElementById("presupuesto").appendChild(presupuesto)
                    document.getElementById("ganancia").appendChild(ganancia)
                })
                movieList.appendChild(peliFiltrada)
            }
        }

        searchButton.addEventListener("click", function () {
            movieArray = data
            movieArrayOriginal = data

            let filtValue = searchValue.value.toUpperCase()
            let filteredMovies = movieArrayOriginal.filter(movie => {
                return movie.title.toUpperCase().includes(filtValue) || movie.overview.toUpperCase().includes(filtValue) || movie.tagline.toUpperCase().includes(filtValue) || movie.genres[0].name.includes(filtValue)
            })
            movieArray = filteredMovies
            showMovies()
        }
        );

    })

