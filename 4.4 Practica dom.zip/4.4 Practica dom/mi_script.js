document.addEventListener('DOMContentLoaded', function () {
  // Incluye aquí el código necesario para mostrar en el párrafo "info", el número de enlaces de la página :
  let enlace = document.getElementsByTagName('a');
  document.getElementById("info").innerHTML = enlace.length;
  // Incluye aquí el código necesario para mostrar en el párrafo "info", la dirección del penúltimo enlace de la página :
  document.getElementById("info").innerHTML = enlace[5].href;
  // Incluye aquí el código necesario para mostrar en el párrafo "info", el número de enlaces que apuntan a http://prueba/ :

  let contador = 0;
  for (var i = 0; i < enlace.length; i++) {

    if (enlace[i].href == "http://prueba" || enlace[i].href == "http://prueba/") {
      contador++;
    }
  }
  document.getElementById("info").innerHTML = " enlaces apuntan a http://prueba: " + contador


  // Incluye aquí el código necesario para mostrar en el párrafo "info", el número de enlaces del tercer párrafo :
  let parrafo = document.getElementsByTagName('p');
  let enlace3 = parrafo[2].getElementsByTagName('a');
  document.getElementById("info").innerHTML =
    "Numero de enlaces de la pagina: " + enlace.length +
    "<br>Penultimo enlace de la pagina: " + enlace[5].href +
    "<br>Numero de enlaces que enlazan a http://prueba/: " + contador +
    "<br>Numero de enlaces del tercer parrafo: " + enlace3.length;



});