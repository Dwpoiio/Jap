let pNombre = document.getElementById("pNombre"), sNombre = document.getElementById("sNombre"), pApellido = document.getElementById("pApellido"), sApellido = document.getElementById("sApellido"), telefono = document.getElementById("telefono"), email = document.getElementById("email"), btnGuardar = document.getElementById("btnGuardar"), formPerfil = document.getElementById("formPerfil"); /* Recojo todos los elementos mediante ID*/

if (JSON.parse(localStorage.getItem('usuario'))) {
    let usuario = JSON.parse(localStorage.getItem('usuario'));
    if (usuario.primerNombre != undefined) { pNombre.value = usuario.primerNombre };
    if (usuario.segundoNombre != undefined) { sNombre.value = usuario.segundoNombre };
    if (usuario.primerNombre != undefined) { pApellido.value = usuario.primerApellido };
    if (usuario.primerNombre != undefined) { sApellido.value = usuario.segundoApellido };
    if (usuario.primerNombre != undefined) { telefono.value = usuario.telefono };
    if (usuario.email != undefined) { email.value = usuario.email };
}

btnGuardar.addEventListener("click", event => {
    let arrayUsuario = {
        primerNombre: pNombre.value,
        segundoNombre: sNombre.value,
        primerApellido: pApellido.value,
        segundoApellido: sApellido.value,
        email: email.value,
        telefono: telefono.value,
        password: usuario.password,

    };
    localStorage.setItem('usuario', JSON.stringify(arrayUsuario))
});

(function () { // Funcion de bootstrap para validar formulario
    'use strict'
    var forms = document.querySelectorAll('.needs-validation')
    Array.prototype.slice.call(forms)
        .forEach(function (form) {
            form.addEventListener('submit', function (event) {
                if (!form.checkValidity()) { event.preventDefault(), event.stopPropagation() }
                form.classList.add('was-validated')
            }, false)
        })
})()